/**
 * @author 杨大宇
 * @title 一票制出库查询
 * @remark 一票制出库查询
 * @date 2019-03-19 16:57:04
 */
import { Component, OnInit } from '@angular/core';

@Component({
	selector: 'app-integrated-ticketing-out',
	templateUrl: './integrated-ticketing-out.component.html',
	styleUrls: ['./integrated-ticketing-out.component.scss'],
})
export class IntegratedTicketingOutComponent implements OnInit {

	/**
	 * @author 杨大宇
	 * @title 构造函数
	 * @date 2019-03-19 16:57:04
	 */
	constructor() {

	}

	ngOnInit() {

	}

}